<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool 1.0 2019.12.02
 * 
 ********************************************************************************/

$app_list_strings['moduleList']['bf_Connects'] = 'Способы связи';
$app_list_strings['connects_title_list']['null'] = '';
$app_list_strings['connects_title_list']['tvitter'] = 'Tvitter';
$app_list_strings['connects_title_list']['facebook'] = 'Facebook';
$app_list_strings['connects_title_list']['linkedin'] = 'LinkedIn';
$app_list_strings['connects_title_list']['instagram'] = 'Instagram';
$app_list_strings['connects_title_list']['vk'] = 'В контакте';
$app_list_strings['connects_title_list']['ok'] = 'Одноклассники';
$app_list_strings['connects_title_list']['whatsapp'] = 'WhatsApp';
$app_list_strings['connects_title_list']['viber'] = 'Viber';
$app_list_strings['connects_title_list']['skype'] = 'Skype';
$app_list_strings['connects_title_list']['telegram'] = 'Телеграм';