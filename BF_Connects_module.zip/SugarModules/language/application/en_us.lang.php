<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool 1.0 2019.12.02
 * 
 ********************************************************************************/

$app_list_strings['moduleList']['bf_Connects'] = 'Connects';
$app_list_strings['connects_title_list']['null'] = '';
$app_list_strings['connects_title_list']['n_tvitter'] = 'Tvitter';
$app_list_strings['connects_title_list']['n_facebook'] = 'Facebook';
$app_list_strings['connects_title_list']['n_linkedin'] = 'LinkedIn';
$app_list_strings['connects_title_list']['n_instagram'] = 'Instagram';
$app_list_strings['connects_title_list']['n_vk'] = 'VK';
$app_list_strings['connects_title_list']['n_ok'] = 'OK';
$app_list_strings['connects_title_list']['m_whatsapp'] = 'WhatsApp';
$app_list_strings['connects_title_list']['m_viber'] = 'Viber';
$app_list_strings['connects_title_list']['m_skype'] = 'Skype';
$app_list_strings['connects_title_list']['m_telegram'] = 'Telegram';