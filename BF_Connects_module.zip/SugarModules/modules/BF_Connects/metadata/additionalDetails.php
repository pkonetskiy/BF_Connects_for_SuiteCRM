<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool  1.0 2019.12.02
 * Module: BF_Connects
 ********************************************************************************/


?>